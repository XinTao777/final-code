import csv
import time

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def index(request):
    type = []
    type.append("Categories1")
    type.append("Categories2")
    type.append("Categories3")

    return render(request, 'index.html',{'mylist':type})
