import csv
import time

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def index(request):
    type = []
    type.append("Categories1")
    type.append("Categories2")
    type.append("Categories3")
    jishu = 0
    return render(request, 'index.html',{'mylist':type})


@csrf_exempt
def pingfanguiji(request):
    mylist = []
    for num in range(105, 108):
        sonList = []
        csvFile = open("/data/"+str(num)+".csv", "r")
        reader = csv.reader(csvFile)
        for item in reader:
            result = []
            result.append(float(item[2]))
            result.append(float(item[3]))
            sonList.append(result)
        mylist.append(sonList)
    csvFile.close()
    return render(request, 'pingfanguiji.html',{'mylist':mylist})