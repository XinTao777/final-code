from django.db import models


class shdx(models.Model):
    id = models.BigAutoField('id', primary_key=True)
    title = models.TextField('title', db_index=True, default='')
    time = models.CharField('time', max_length=255, db_index=True, default='')
    content = models.TextField('content', db_index=True, default='')