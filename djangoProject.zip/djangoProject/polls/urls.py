from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('pingfanguiji', views.pingfanguiji, name='pingfanguiji'),
    path('idchaxun', views.idchaxun, name='idchaxun'),
    path('idchaxunquery', views.idchaxunquery, name='idchaxunquery'),
    path('shijianchaxun', views.shijianchaxun, name='shijianchaxun'),
    path('shijianchaxunquery', views.shijianchaxunquery, name='shijianchaxunquery'),


]